/* -----------------------------------------------------------------------------
*	@author Guhyoun Nam
* @file Shape.cpp
* @date 2/17/2020
* @brief cpp file of Shape
 ---------------------------------------------------------------------------- */
//Start your program.
//#include "Shape.h"
